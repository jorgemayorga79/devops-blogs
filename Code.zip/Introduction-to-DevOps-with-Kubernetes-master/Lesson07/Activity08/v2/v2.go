package main

import "time"

func main() {
	time.Sleep(10000 * time.Second)
}
