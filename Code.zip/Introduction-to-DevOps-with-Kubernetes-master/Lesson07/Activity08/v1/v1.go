package main

func main() {
	i := 1
	for {
		_ = i * i
		i++
	}
}
